import 'package:hotel_booking/features/auth/domain/repository/user_repository.dart';
import 'package:mocktail/mocktail.dart';

class UserRepoMock extends Mock implements IUserRepository {}
