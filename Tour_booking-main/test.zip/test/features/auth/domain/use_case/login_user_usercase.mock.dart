import 'package:hotel_booking/features/auth/domain/use_case/login_user_usecase.dart';
import 'package:mocktail/mocktail.dart';

class MockLoginUserUseCase extends Mock implements LoginUserUsecase{

}