

import 'package:flutter_test/flutter_test.dart';
import 'package:hotel_booking/features/auth/presentation/view_model/signup/register_bloc.dart';

class FakeRegisterStudent extends Fake implements RegisterUser {}