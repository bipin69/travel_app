
import 'package:hotel_booking/features/home/presentation/view_model/home_cubit.dart';
import 'package:mocktail/mocktail.dart';

class MockHomeCubit extends Mock implements HomeCubit {}