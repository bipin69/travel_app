// Mock class for BuildContext
import 'package:flutter/material.dart';
import 'package:mocktail/mocktail.dart';

class MockBuildContext extends Mock implements BuildContext {}